<?php
include('db.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_barang = $_POST['nama_barang'];
    $jumlah = $_POST['jumlah'];
    $harga_per_unit = $_POST['harga'];
    $total_harga = $jumlah * $harga_per_unit;
    $tanggal = date('Y-m-d');

    // Catat pembelian
    $conn->query("INSERT INTO pembelian (nama_barang, jumlah, harga, total_harga, tanggal) 
                  VALUES ('$nama_barang', '$jumlah', '$harga_per_unit', '$total_harga', '$tanggal')");

    // Update stok di tabel barang
    $result = $conn->query("SELECT * FROM barang WHERE nama='$nama_barang'");
    if ($result->num_rows > 0) {
        // Update jika barang sudah ada
        $conn->query("UPDATE barang SET stok = stok + $jumlah, jumlah = jumlah + $jumlah WHERE nama='$nama_barang'");
    }

    header('Location: pembelian.php');
}

$conn->close();