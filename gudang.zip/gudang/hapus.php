<?php
include('db.php');

$id = $_GET['id'];

$sql = "DELETE FROM barang WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    header('Location: masuk.php');
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();