<?php include('db.php'); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Barang Keluar</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <div class="container mt-5">
        <h2>Tambah Barang Keluar</h2>
        <form action="proses_barang_keluar.php" method="post">
            <div class="form-group">
                <label>Nama Barang</label>
                <select name="nama" class="form-control" required>
                    <option value="">Pilih Barang</option>
                    <?php
                    $result = $conn->query("SELECT nama FROM barang");
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='{$row['nama']}'>{$row['nama']}</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label>Jumlah Keluar</label>
                <input type="number" name="jumlah" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-success">Simpan</button>
            <a href="index.php" class="btn btn-secondary">Kembali</a>
        </form>

        <?php if (isset($_GET['error'])) : ?>
        <div class="alert alert-danger mt-3">
            <?= htmlspecialchars($_GET['error']); ?>
        </div>
        <?php endif; ?>
    </div>
</body>

</html>