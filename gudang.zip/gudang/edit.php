<?php
include('db.php');

$id = $_GET['id'];
$result = $conn->query("SELECT * FROM barang WHERE id=$id");
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Barang</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <div class="container mt-5">
        <h2>Edit Barang</h2>
        <form action="update.php" method="post">
            <input type="hidden" name="id" value="<?= $row['id']; ?>">
            <div class="form-group">
                <label>Nama Barang</label>
                <input type="text" name="nama" class="form-control" value="<?= $row['nama']; ?>" required>
            </div>
            <div class="form-group">
                <label>Kategori</label>
                <input type="text" name="kategori" class="form-control" value="<?= $row['kategori']; ?>" required>
            </div>
            <div class="form-group">
                <label>Jumlah</label>
                <input type="number" name="jumlah" class="form-control" value="<?= $row['jumlah']; ?>" required>
            </div>
            <div class="form-group">
                <label>Harga</label>
                <input type="number" step="0.01" name="harga" class="form-control" value="<?= $row['harga']; ?>"
                    required>
            </div>
            <div class="form-group">
                <label>Tanggal Masuk</label>
                <input type="date" name="tanggal_masuk" class="form-control" value="<?= $row['tanggal_masuk']; ?>"
                    required>
            </div>
            <button type="submit" class="btn btn-success">Update</button>
            <a href="index.php" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
</body>

</html>