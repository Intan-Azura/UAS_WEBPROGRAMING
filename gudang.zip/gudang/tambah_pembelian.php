<?php include('db.php'); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pembelian Barang</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <div class="container mt-5">
        <h2>Tambah Pembelian Barang</h2>
        <form action="proses_pembelian.php" method="post">
            <div class="form-group">
                <label>Nama Barang</label>
                <select name="nama_barang" id="nama_barang" class="form-control" onchange="getBarangDetails()" required>
                    <option value="">Pilih Barang</option>
                    <?php
                    $result = $conn->query("SELECT nama, harga FROM barang");
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='{$row['nama']}' data-harga='{$row['harga']}'>{$row['nama']}</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label>Harga</label>
                <input type="number" step="0.01" name="harga" id="harga" class="form-control" readonly required>
            </div>
            <div class="form-group">
                <label>Jumlah</label>
                <input type="number" name="jumlah" id="jumlah" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-success">Simpan</button>
            <a href="index.php" class="btn btn-secondary">Kembali</a>
        </form>
    </div>

    <script>
    function getBarangDetails() {
        var nama_barang = document.getElementById("nama_barang").value;
        var options = document.getElementById("nama_barang").options;
        var selectedOption = options[options.selectedIndex];
        var harga = selectedOption.getAttribute('data-harga');

        document.getElementById("harga").value = harga;
    }
    </script>

</body>

</html>