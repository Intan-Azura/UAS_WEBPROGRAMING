<?php
include('db.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $jumlah = $_POST['jumlah'];
    $tanggal = date('Y-m-d');

    // Cek stok barang
    $result = $conn->query("SELECT stok FROM barang WHERE nama='$nama'");
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if ($row['stok'] >= $jumlah) {
            // Kurangi stok
            $conn->query("UPDATE barang SET stok = stok - $jumlah WHERE nama='$nama'");

            // Catat barang keluar
            $conn->query("INSERT INTO barang_keluar (nama_barang, jumlah, tanggal) VALUES ('$nama', '$jumlah', '$tanggal')");

            header('Location: index.php');
        } else {
            $error = "Stok tidak mencukupi!";
            header("Location: tambah_barang_keluar.php?error=$error");
        }
    } else {
        $error = "Barang tidak ditemukan!";
        header("Location: tambah_barang_keluar.php?error=$error");
    }
}

$conn->close();