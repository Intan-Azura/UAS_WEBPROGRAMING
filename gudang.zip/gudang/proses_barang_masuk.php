<?php
include('db.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $kategori = $_POST['kategori'];
    $jumlah = $_POST['jumlah'];
    $harga = $_POST['harga'];
    $tanggal_masuk = $_POST['tanggal_masuk'];

    // Cek apakah barang sudah ada
    $result = $conn->query("SELECT * FROM barang WHERE nama='$nama'");
    if ($result->num_rows > 0) {
        // Update stok jika barang sudah ada
        $conn->query("UPDATE barang SET stok = stok + $jumlah WHERE nama='$nama'");
    } else {
        // Tambahkan barang baru jika belum ada
        $conn->query("INSERT INTO barang (nama, kategori, jumlah, harga, tanggal_masuk, stok) 
                      VALUES ('$nama', '$kategori', '$jumlah', '$harga', '$tanggal_masuk', '$jumlah')");
    }

    header('Location: index.php');
}

$conn->close();